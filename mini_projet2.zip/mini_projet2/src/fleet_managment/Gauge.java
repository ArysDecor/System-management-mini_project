// Classe Gauge.java
package fleet_managment;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;

public class Gauge extends JPanel {
    private String title;
    private String unit;
    private float minValue;
    private float maxValue;
    private float currentValue;
    
    public Gauge(String title, String unit, float minValue, float maxValue) {
        this.title = title;
        this.unit = unit;
        this.minValue = minValue;
        this.maxValue = maxValue;
        this.currentValue = minValue;
        setPreferredSize(new Dimension(200, 200));
        setBackground(Color.DARK_GRAY);
    }
    
    public void setValue(float value) {
        this.currentValue = Math.max(minValue, Math.min(maxValue, value));
        repaint();
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        int size = Math.min(getWidth(), getHeight()) - 40;
        int centerX = getWidth() / 2;
        int centerY = getHeight() / 2 + 10;
        int radius = size / 2;
        
        // Dessiner le fond du cadran
        g2.setColor(new Color(40, 40, 40));
        g2.fillArc(centerX - radius, centerY - radius, size, size, 0, 180);
        
        // Dessiner les zones color�es de fond
        drawColorZones(g2, centerX, centerY, radius);
        
        // Dessiner les graduations principales
        drawMajorTicks(g2, centerX, centerY, radius);
        
        // Dessiner les graduations mineures
        drawMinorTicks(g2, centerX, centerY, radius);
        
        // Dessiner les valeurs num�riques
        drawNumbers(g2, centerX, centerY, radius);
        
        // Dessiner l'aiguille
        drawNeedle(g2, centerX, centerY, radius);
        
        // Dessiner le centre de l'aiguille
        g2.setColor(Color.DARK_GRAY);
        g2.fillOval(centerX - 8, centerY - 8, 16, 16);
        g2.setColor(Color.LIGHT_GRAY);
        g2.drawOval(centerX - 8, centerY - 8, 16, 16);
        
        // Dessiner le titre
     // Dessiner le titre (position ajust�e)
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Arial", Font.BOLD, 14));
        FontMetrics fm = g2.getFontMetrics();
        int titleWidth = fm.stringWidth(title);
        g2.drawString(title, centerX - titleWidth / 2, 20); // Valeur '20' � ajuster selon vos besoins
        
        // Dessiner la valeur actuelle
        g2.setFont(new Font("Arial", Font.BOLD, 16));
        String valueText = String.format("%.1f %s", currentValue, unit);
        fm = g2.getFontMetrics();
        int valueWidth = fm.stringWidth(valueText);
        g2.drawString(valueText, centerX - valueWidth / 2, centerY + 30);
    }
    
    private void drawColorZones(Graphics2D g2, int centerX, int centerY, int radius) {
        int innerRadius = (int)(radius * 0.75);
        int outerRadius = (int)(radius * 0.9);
        
        // Zone verte (0-60% de la plage)
        g2.setColor(new Color(255, 0, 0, 100));
        g2.fillArc(centerX - outerRadius, centerY - outerRadius, outerRadius * 2, outerRadius * 2, 0, 108);
        g2.setColor(Color.DARK_GRAY);
        g2.fillArc(centerX - innerRadius, centerY - innerRadius, innerRadius * 2, innerRadius * 2, 0, 108);
        
        // Zone jaune (60-80% de la plage)
        g2.setColor(new Color(255, 255, 0, 100));
        g2.fillArc(centerX - outerRadius, centerY - outerRadius, outerRadius * 2, outerRadius * 2, 108, 36);
        g2.setColor(Color.DARK_GRAY);
        g2.fillArc(centerX - innerRadius, centerY - innerRadius, innerRadius * 2, innerRadius * 2, 108, 36);
        
        // Zone rouge (80-100% de la plage)
        g2.setColor(new Color(0, 150, 0, 100));
        g2.fillArc(centerX - outerRadius, centerY - outerRadius, outerRadius * 2, outerRadius * 2, 144, 36);
        g2.setColor(Color.DARK_GRAY);
        g2.fillArc(centerX - innerRadius, centerY - innerRadius, innerRadius * 2, innerRadius * 2, 144, 36);
    }
    
    private void drawMajorTicks(Graphics2D g2, int centerX, int centerY, int radius) {
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(2));
        
        int numMajorTicks = 6; // 0, 20, 40, 60, 80, 100%
        for (int i = 0; i <= numMajorTicks; i++) {
            double angle = Math.toRadians(180 - (i * 180.0 / numMajorTicks));
            int x1 = centerX + (int)(Math.cos(angle) * (radius - 15));
            int y1 = centerY - (int)(Math.sin(angle) * (radius - 15));
            int x2 = centerX + (int)(Math.cos(angle) * (radius - 5));
            int y2 = centerY - (int)(Math.sin(angle) * (radius - 5));
            
            g2.drawLine(x1, y1, x2, y2);
        }
    }
    
    private void drawMinorTicks(Graphics2D g2, int centerX, int centerY, int radius) {
        g2.setColor(Color.LIGHT_GRAY);
        g2.setStroke(new BasicStroke(1));
        
        int numMinorTicks = 30; // Graduations mineures
        for (int i = 0; i <= numMinorTicks; i++) {
            if (i % 6 != 0) { // Ne pas dessiner sur les graduations principales
                double angle = Math.toRadians(180 - (i * 180.0 / numMinorTicks));
                int x1 = centerX + (int)(Math.cos(angle) * (radius - 10));
                int y1 = centerY - (int)(Math.sin(angle) * (radius - 10));
                int x2 = centerX + (int)(Math.cos(angle) * (radius - 5));
                int y2 = centerY - (int)(Math.sin(angle) * (radius - 5));
                
                g2.drawLine(x1, y1, x2, y2);
            }
        }
    }
    
    private void drawNumbers(Graphics2D g2, int centerX, int centerY, int radius) {
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Arial", Font.BOLD, 12));
        FontMetrics fm = g2.getFontMetrics();
        
        int numLabels = 6;
        for (int i = 0; i <= numLabels; i++) {
            double angle = Math.toRadians(180 - (i * 180.0 / numLabels));
            float value = minValue + (maxValue - minValue) * i / numLabels;
            String label = String.format("%.0f", value);
            
            int textRadius = radius - 25;
            int x = centerX + (int)(Math.cos(angle) * textRadius) - fm.stringWidth(label) / 2;
            int y = centerY - (int)(Math.sin(angle) * textRadius) + fm.getAscent() / 2;
            
            g2.drawString(label, x, y);
        }
    }
    
    private void drawNeedle(Graphics2D g2, int centerX, int centerY, int radius) {
        // Calculer l'angle de l'aiguille
        float valueRatio = (currentValue - minValue) / (maxValue - minValue);
        double needleAngle = Math.toRadians(180 - (valueRatio * 180));
        
        // Coordonn�es de l'aiguille
        int needleLength = (int)(radius * 0.7);
        int needleX = centerX + (int)(Math.cos(needleAngle) * needleLength);
        int needleY = centerY - (int)(Math.sin(needleAngle) * needleLength);
        
        // Dessiner l'aiguille principale
        g2.setColor(Color.RED);
        g2.setStroke(new BasicStroke(3, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2.drawLine(centerX, centerY, needleX, needleY);
        
        // Dessiner la queue de l'aiguille (c�t� oppos�)
        int tailLength = 20;
        int tailX = centerX - (int)(Math.cos(needleAngle) * tailLength);
        int tailY = centerY + (int)(Math.sin(needleAngle) * tailLength);
        g2.setStroke(new BasicStroke(2));
        g2.drawLine(centerX, centerY, tailX, tailY);
        
        // Dessiner une pointe triangulaire � l'aiguille
        int[] xPoints = new int[3];
        int[] yPoints = new int[3];
        
        // Point de la pointe
        xPoints[0] = needleX;
        yPoints[0] = needleY;
        
        // Points de la base du triangle
        double perpAngle1 = needleAngle + Math.PI/2;
        double perpAngle2 = needleAngle - Math.PI/2;
        int baseOffset = 3;
        
        xPoints[1] = centerX + (int)(Math.cos(perpAngle1) * baseOffset);
        yPoints[1] = centerY - (int)(Math.sin(perpAngle1) * baseOffset);
        xPoints[2] = centerX + (int)(Math.cos(perpAngle2) * baseOffset);
        yPoints[2] = centerY - (int)(Math.sin(perpAngle2) * baseOffset);
        
        g2.setColor(Color.RED);
        g2.fillPolygon(xPoints, yPoints, 3);
    }
}