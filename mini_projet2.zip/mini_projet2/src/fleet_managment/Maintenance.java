package fleet_managment;

import java.sql.Date;

public class Maintenance {
	private int id_maintenance;
	private Vehicle vehicle;
	private Date date;
	private String description;
	public Maintenance(int id_maintenance, Vehicle vehicle, Date date, String description){
		this.id_maintenance = id_maintenance;
		this.vehicle = vehicle;
		this.date = date;
		this.description = description;
	}
	public int getId_maintenance() {
		return id_maintenance;
	}
	public void setId_maintenance(int id_maintenance) {
		this.id_maintenance = id_maintenance;
	}
	public Vehicle getVehicle() {
		return vehicle;
	}
	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

}
