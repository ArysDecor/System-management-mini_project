package fleet_managment;
import fleet_managment.Vehicle;

public class Driver {
    private int id_driver;
    private String name;
    private String phoneNumber;
    private String vehicle; // Nom du v�hicule assign�
    
    public Driver(int id_driver, String name, String phoneNumber, String vehicle) {
        this.id_driver = id_driver;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.vehicle = vehicle;
    }

	public int getId_driver() {
		return id_driver;
	}

	public void setId_driver(int id_driver) {
		this.id_driver = id_driver;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getVehicle() {
		return vehicle;
	}

	public void setVehicle(String vehicle) {
		this.vehicle = vehicle;
	}
    
}