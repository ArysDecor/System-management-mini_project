package fleet_managment;

import javax.swing.*;
import java.awt.*;

public class LevelIndicator extends JPanel {
    private float oilLevel = 75.0f;
    private String title;
    private final Color BACKGROUND_COLOR = Color.DARK_GRAY;
    private final Color BORDER_COLOR = Color.DARK_GRAY;
    private final Color TEXT_COLOR = Color.WHITE;
    private final Color LOW_COLOR = new Color(220, 50, 50);
    private final Color MEDIUM_COLOR = new Color(255, 165, 0);
    private final Color GOOD_COLOR = new Color(50, 200, 50);

    public LevelIndicator(String title) {
        this.title = title;
        setPreferredSize(new Dimension(200, 250));
        setBackground(BACKGROUND_COLOR);
        setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 2),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
    }

    public void setOilLevel(float level) {
        this.oilLevel = Math.max(0, Math.min(100, level));
        repaint();
    }

    public float getOilLevel() {
        return oilLevel;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();
        
        // Titre
        g2d.setColor(TEXT_COLOR);
        g2d.setFont(new Font("Arial", Font.BOLD, 14));
        FontMetrics fm = g2d.getFontMetrics();
        String displayTitle = "🛢️ " + title.toUpperCase();
        int titleWidth = fm.stringWidth(displayTitle);
        g2d.drawString(displayTitle, (width - titleWidth) / 2, 25);

        // Indicateur principal
        int indicatorWidth = 120;
        int indicatorHeight = 180;
        int indicatorX = (width - indicatorWidth) / 2;
        int indicatorY = 35;

        // Fond de l'indicateur
        g2d.setColor(new Color(50, 50, 50));
        g2d.fillRoundRect(indicatorX, indicatorY, indicatorWidth, indicatorHeight, 10, 10);
        g2d.setColor(BORDER_COLOR);
        g2d.setStroke(new BasicStroke(2));
        g2d.drawRoundRect(indicatorX, indicatorY, indicatorWidth, indicatorHeight, 10, 10);

        // Zones de couleur (fond)
        int zoneHeight = indicatorHeight - 6;
        int zoneY = indicatorY + 3;
        int zoneX = indicatorX + 3;
        int zoneWidth = indicatorWidth - 6;
        
        // Zone rouge (0-25%)
        g2d.setColor(new Color(LOW_COLOR.getRed(), LOW_COLOR.getGreen(), LOW_COLOR.getBlue(), 60));
        g2d.fillRect(zoneX, zoneY + (int)(zoneHeight * 0.75), zoneWidth, (int)(zoneHeight * 0.25));
        
        // Zone orange (25-50%)
        g2d.setColor(new Color(MEDIUM_COLOR.getRed(), MEDIUM_COLOR.getGreen(), MEDIUM_COLOR.getBlue(), 60));
        g2d.fillRect(zoneX, zoneY + (int)(zoneHeight * 0.5), zoneWidth, (int)(zoneHeight * 0.25));
        
        // Zone verte (50-100%)
        g2d.setColor(new Color(GOOD_COLOR.getRed(), GOOD_COLOR.getGreen(), GOOD_COLOR.getBlue(), 60));
        g2d.fillRect(zoneX, zoneY, zoneWidth, (int)(zoneHeight * 0.5));

        // Niveau d'huile actuel
        float levelRatio = oilLevel / 100.0f;
        int fillHeight = (int)(zoneHeight * levelRatio);
        int fillY = zoneY + zoneHeight - fillHeight;
        
        Color levelColor;
        if (oilLevel < 25) levelColor = LOW_COLOR;
        else if (oilLevel < 50) levelColor = MEDIUM_COLOR;
        else levelColor = GOOD_COLOR;
        
        g2d.setColor(levelColor);
        g2d.fillRect(zoneX, fillY, zoneWidth, fillHeight);

        // Lignes de graduation
        g2d.setColor(Color.GRAY);
        g2d.setStroke(new BasicStroke(1));
        for (int i = 0; i <= 8; i++) {
            int lineY = zoneY + (int)(zoneHeight * i / 8.0);
            g2d.drawLine(zoneX, lineY, zoneX + zoneWidth, lineY);
        }

        // Étiquettes MIN/MAX
        g2d.setColor(TEXT_COLOR);
        g2d.setFont(new Font("Arial", Font.PLAIN, 10));
        g2d.drawString("MAX", indicatorX + indicatorWidth + 5, indicatorY + 15);
        g2d.drawString("MIN", indicatorX + indicatorWidth + 5, indicatorY + indicatorHeight - 5);

        // Affichage du pourcentage (réintégré)
        g2d.setFont(new Font("Arial", Font.BOLD, 18));
        String valueText = String.format("%.0f%%", oilLevel);
        fm = g2d.getFontMetrics();
        int valueWidth = fm.stringWidth(valueText);
        g2d.setColor(levelColor);
        g2d.drawString(valueText, (width - valueWidth) / 2, height - 15);
    }
}