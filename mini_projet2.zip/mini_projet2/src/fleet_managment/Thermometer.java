// Classe Thermometer.java
package fleet_managment;
import javax.swing.*;
import java.awt.*;

public class Thermometer extends JPanel {
    private String title;
    private float temperature;
    private float minTemp = -20;
    private float maxTemp = 120;
    
    public Thermometer(String title) {
        this.title = title;
        this.temperature = 20;
        setPreferredSize(new Dimension(150, 200));
        setBackground(Color.DARK_GRAY);
    }
    
    public void setTemperature(float temp) {
        this.temperature = temp;
        repaint();
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        int width = getWidth();
        int height = getHeight();
        
        // Dimensions du thermom�tre
        int bulbDiameter = 35;
        int stemWidth = 16;
        int stemHeight = height - bulbDiameter - 60; // Plus de place pour le titre
        int bulbX = (width - bulbDiameter) / 2;
        int bulbY = height - bulbDiameter - 40;
        int stemX = (width - stemWidth) / 2;
        int stemY = 30;
        
        // Dessiner l'�chelle gradu�e d'abord
        drawScale(g2, stemX, stemY, stemHeight);
        
        // Contour ext�rieur du thermom�tre
        g2.setColor(new Color(180, 180, 180));
        g2.setStroke(new BasicStroke(2));
        g2.drawRoundRect(stemX - 2, stemY - 2, stemWidth + 4, stemHeight + 4, 12, 12);
        g2.drawOval(bulbX - 2, bulbY - 2, bulbDiameter + 4, bulbDiameter + 4);
        
        // Fond de la tige (vide)
        g2.setColor(new Color(240, 240, 240));
        g2.fillRoundRect(stemX, stemY, stemWidth, stemHeight, 10, 10);
        
        // Fond du bulbe
        g2.setColor(new Color(240, 240, 240));
        g2.fillOval(bulbX, bulbY, bulbDiameter, bulbDiameter);
        
        // Calculer la hauteur du liquide
        float tempRatio = (temperature - minTemp) / (maxTemp - minTemp);
        tempRatio = Math.max(0, Math.min(1, tempRatio)); // Limiter entre 0 et 1
        float liquidHeight = stemHeight * tempRatio;
        
        // Dessiner le liquide
        Color liquidColor = getTemperatureColor(temperature);
        g2.setColor(liquidColor);
        
        // Liquide dans la tige
        if (liquidHeight > 0) {
            g2.fillRoundRect(stemX + 2, 
                            (int) (stemY + stemHeight - liquidHeight), 
                            stemWidth - 4, 
                            (int) liquidHeight, 6, 6);
        }
        
        // Liquide dans le bulbe (toujours rempli)
        g2.fillOval(bulbX + 2, bulbY + 2, bulbDiameter - 4, bulbDiameter - 4);
        
        // Effet de brillance sur le liquide
        g2.setColor(new Color(255, 255, 255, 100));
        if (liquidHeight > 0) {
            g2.fillRoundRect(stemX + 3, 
                            (int) (stemY + stemHeight - liquidHeight), 
                            3, 
                            (int) liquidHeight, 3, 3);
        }
        g2.fillOval(bulbX + 3, bulbY + 3, 8, 8);
        
        // Dessiner le titre
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Arial", Font.BOLD, 12));
        FontMetrics fm = g2.getFontMetrics();
        int titleWidth = fm.stringWidth(title);
        g2.drawString(title, (width - titleWidth) / 2, height - 20);
        
        // Afficher la temp�rature actuelle
        g2.setFont(new Font("Arial", Font.BOLD, 14));
        String tempText = String.format("%.1f�C", temperature);
        fm = g2.getFontMetrics();
        int tempWidth = fm.stringWidth(tempText);
        g2.drawString(tempText, (width - tempWidth) / 2, height - 5);
        
        // Indicateur num�rique sur le c�t�
        drawTemperatureIndicator(g2, stemX + stemWidth + 8, stemY, stemHeight, tempRatio);
    }
    
    private void drawScale(Graphics2D g2, int stemX, int stemY, int stemHeight) {
        g2.setFont(new Font("Arial", Font.PLAIN, 9));
        FontMetrics fm = g2.getFontMetrics();
        
        // Graduations principales (tous les 20�C)
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(1));
        
        for (int temp = (int)minTemp; temp <= maxTemp; temp += 20) {
            float ratio = (temp - minTemp) / (maxTemp - minTemp);
            int y = (int)(stemY + stemHeight - (ratio * stemHeight));
            
            // Trait de graduation principal
            g2.drawLine(stemX - 8, y, stemX - 2, y);
            
            // Valeur num�rique
            String label = String.valueOf(temp);
            int labelWidth = fm.stringWidth(label);
            g2.drawString(label, stemX - 12 - labelWidth, y + 3);
        }
        
        // Graduations secondaires (tous les 10�C)
        g2.setColor(Color.LIGHT_GRAY);
        for (int temp = (int)minTemp + 10; temp < maxTemp; temp += 20) {
            float ratio = (temp - minTemp) / (maxTemp - minTemp);
            int y = (int)(stemY + stemHeight - (ratio * stemHeight));
            
            // Trait de graduation secondaire
            g2.drawLine(stemX - 6, y, stemX - 2, y);
        }
        
        // Graduations mineures (tous les 5�C)
        g2.setColor(Color.GRAY);
        for (int temp = (int)minTemp; temp <= maxTemp; temp += 5) {
            if (temp % 10 != 0) { // Ne pas dessiner sur les graduations principales et secondaires
                float ratio = (temp - minTemp) / (maxTemp - minTemp);
                int y = (int)(stemY + stemHeight - (ratio * stemHeight));
                
                // Petit trait de graduation
                g2.drawLine(stemX - 4, y, stemX - 2, y);
            }
        }
    }
    
    private void drawTemperatureIndicator(Graphics2D g2, int x, int stemY, int stemHeight, float tempRatio) {
        // Dessiner un petit indicateur triangulaire pour la temp�rature actuelle
        int indicatorY = (int)(stemY + stemHeight - (tempRatio * stemHeight));
        
        g2.setColor(Color.YELLOW);
        int[] xPoints = {x, x + 8, x};
        int[] yPoints = {indicatorY - 4, indicatorY, indicatorY + 4};
        g2.fillPolygon(xPoints, yPoints, 3);
        
        g2.setColor(Color.ORANGE);
        g2.drawPolygon(xPoints, yPoints, 3);
    }
    
    private Color getTemperatureColor(float temp) {
        if (temp < 0) return new Color(0, 100, 255);      // Bleu froid
        if (temp < 20) return new Color(0, 150, 255);     // Bleu
        if (temp < 40) return new Color(0, 255, 200);     // Cyan
        if (temp < 60) return new Color(0, 255, 0);       // Vert
        if (temp < 80) return new Color(255, 255, 0);     // Jaune
        if (temp < 100) return new Color(255, 150, 0);    // Orange
        return new Color(255, 0, 0);                      // Rouge chaud
    }
}