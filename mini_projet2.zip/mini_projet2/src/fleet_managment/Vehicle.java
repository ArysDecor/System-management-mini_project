package fleet_managment;

public class Vehicle {
    private int id;
    private float speed;
    private float fuel;
    private float temperature;
    private float mileage;

    public Vehicle(int id, float speed, float fuel, float temperature, float mileage) {
        this.id = id;
        this.speed = speed;
        this.fuel = fuel;
        this.temperature = temperature;
        this.mileage = mileage;
    }

    public int getId() { return id; }
    public float getSpeed() { return speed; }
    public float getFuel() { return fuel; }
    public float getTemperature() { return temperature; }
    public float getMileage() { return mileage; }

    public void setSpeed(float speed) { this.speed = speed; }
    public void setFuel(float fuel) { this.fuel = fuel; }
    public void setTemperature(float temperature) { this.temperature = temperature; }
    public void setMileage(float mileage) { this.mileage = mileage; }
}
