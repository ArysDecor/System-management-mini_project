package fleet_managment;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class Dashboard extends JFrame {
	private Gauge[][] gauges = new Gauge[10][10];
	private LevelIndicator[][] levelIndicators = new LevelIndicator[10][3]; // [véhicule][type de niveau]
    private Thermometer[] thermometers = new Thermometer[10];
    private Thermometer[] extThermometers = new Thermometer[10];
    private JTabbedPane tabbedPane;
    private JTextField searchField;
    private List<String> vehicleNames = new ArrayList<>();
    private List<JPanel> vehiclePanels = new ArrayList<>();
    private JLabel[][] tirePressureLabels = new JLabel[10][4];
    private JPanel[][] tirePanels = new JPanel[10][4];
    private JLabel[] dtcLabels = new JLabel[10];
    private JPanel[] dtcPanels = new JPanel[10];
    private JLabel[] smokeLabels = new JLabel[10];
    private JPanel[] smokePanels = new JPanel[10];
    private JLabel[] vibrationLabels = new JLabel[10];
    private JPanel[] vibrationPanels = new JPanel[10];
    
    private List<Driver> drivers = new ArrayList<>();
    private JTable driversTable;
    private DefaultTableModel tableModel;
    private JTextField driverSearchField;

    // Système d'alertes
    private JPanel alertsPanel;
    private DefaultListModel<String> alertsListModel;
    private JList<String> alertsList;
    private Map<String, String> alertSeverity = new HashMap<>();
    private JScrollPane alertsScrollPane;

    private final String[] DTC_CODES = {
        "P0000", "P0420", "P0171", "P0300", "P0128", 
        "P0455", "P0700", "P0562", "P0011", "P0340"
    };

    public Dashboard() {
        setTitle("Dashboard des véhicules - Système d'Alertes");
        setSize(1400, 1000);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        initializeDrivers();
        initializeAlertsPanel();

        // Panel pour recherche
        JPanel searchPanel = new JPanel(new BorderLayout(5, 0));
        searchPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        searchPanel.setBackground(Color.DARK_GRAY);

        JLabel searchIcon = new JLabel("🔍");
        searchIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 18));
        searchIcon.setForeground(Color.LIGHT_GRAY);
        searchIcon.setBorder(new EmptyBorder(0, 5, 0, 5));
        searchPanel.add(searchIcon, BorderLayout.WEST);

        searchField = new JTextField();
        searchField.setForeground(Color.WHITE);
        searchField.setBackground(new Color(60, 63, 65));
        searchField.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        addPlaceholder(searchField, "Rechercher un véhicule par ID...");
        searchPanel.add(searchField, BorderLayout.CENTER);
        add(searchPanel, BorderLayout.NORTH);

        tabbedPane = new JTabbedPane(JTabbedPane.LEFT);
        tabbedPane.setBackground(Color.DARK_GRAY);
        tabbedPane.setForeground(Color.white);
        
        tabbedPane.addTab("👥 Conducteurs", createDriversPanel());
        add(tabbedPane, BorderLayout.CENTER);

        createVehiclePanels();

        // Panel pour les alertes en bas
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        bottomPanel.setBackground(Color.DARK_GRAY);
        bottomPanel.add(alertsPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // Listener pour la recherche
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) { filterTabs(); }
            public void removeUpdate(DocumentEvent e) { filterTabs(); }
            public void insertUpdate(DocumentEvent e) { filterTabs(); }
        });

        // Timer pour mettre à jour les valeurs toutes les 3 secondes
        Timer timer = new Timer(3000, e -> updateValues());
        timer.start();
    }

    private void initializeAlertsPanel() {
        alertsPanel = new JPanel(new BorderLayout());
        alertsPanel.setBackground(new Color(40, 40, 40));
        alertsPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.RED, 2),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        JLabel alertsTitle = new JLabel("🚨 ALERTES VÉHICULES", SwingConstants.CENTER);
        alertsTitle.setForeground(Color.WHITE);
        alertsTitle.setFont(new Font("Arial", Font.BOLD, 16));
        alertsPanel.add(alertsTitle, BorderLayout.NORTH);
        
        alertsListModel = new DefaultListModel<>();
        alertsList = new JList<>(alertsListModel);
        alertsList.setBackground(new Color(60, 60, 60));
        alertsList.setForeground(Color.WHITE);
        alertsList.setFont(new Font("Arial", Font.PLAIN, 12));
        alertsList.setSelectionBackground(new Color(80, 80, 80));
        alertsList.setCellRenderer(new AlertListCellRenderer());
        
        alertsScrollPane = new JScrollPane(alertsList);
        alertsScrollPane.setBorder(BorderFactory.createEmptyBorder());
        alertsPanel.add(alertsScrollPane, BorderLayout.CENTER);
        
        // Panel pour les boutons
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        buttonPanel.setBackground(new Color(40, 40, 40));
        
        // Bouton pour fermer les alertes sélectionnées
        JButton closeAlertButton = new JButton("Fermer l'alerte");
        closeAlertButton.setBackground(new Color(180, 70, 70));
        closeAlertButton.setForeground(Color.WHITE);
        closeAlertButton.addActionListener(e -> closeSelectedAlert());
        buttonPanel.add(closeAlertButton);

        // Bouton pour tout effacer
        JButton clearAllButton = new JButton("Tout effacer");
        clearAllButton.setBackground(new Color(100, 100, 100));
        clearAllButton.setForeground(Color.WHITE);
        clearAllButton.addActionListener(e -> {
            alertsListModel.clear();
            alertSeverity.clear();
        });
        buttonPanel.add(clearAllButton);
        
        alertsPanel.add(buttonPanel, BorderLayout.SOUTH);
    }

    class AlertListCellRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index, 
                                                     boolean isSelected, boolean cellHasFocus) {
            Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            
            String alert = (String) value;
            String severity = alertSeverity.get(alert);
            
            if (severity != null) {
                switch (severity) {
                    case "CRITIQUE":
                        c.setForeground(Color.RED);
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                        break;
                    case "HAUTE":
                        c.setForeground(Color.ORANGE);
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                        break;
                    case "MOYENNE":
                        c.setForeground(Color.YELLOW);
                        break;
                    case "BASSE":
                        c.setForeground(Color.CYAN);
                        break;
                }
            }
            
            if (isSelected) {
                c.setBackground(new Color(80, 80, 80));
            }
            
            return c;
        }
    }

    private void closeSelectedAlert() {
        int selectedIndex = alertsList.getSelectedIndex();
        if (selectedIndex != -1) {
            String alert = alertsListModel.getElementAt(selectedIndex);
            alertsListModel.remove(selectedIndex);
            alertSeverity.remove(alert);
        } else {
            JOptionPane.showMessageDialog(this, 
                "Veuillez sélectionner une alerte à fermer.", 
                "Aucune sélection", 
                JOptionPane.WARNING_MESSAGE);
        }
    }

    private void initializeDrivers() {
        Random rand = new Random();
        drivers.add(new Driver(1, "Jean Dupont", "+212 6 12 34 56 78", rand.nextBoolean() ? "Véhicule 1" : null));
        drivers.add(new Driver(2, "Marie Martin", "+212 6 87 65 43 21", rand.nextBoolean() ? "Véhicule 3" : null));
        drivers.add(new Driver(3, "Ahmed Alami", "+212 6 11 22 33 44", rand.nextBoolean() ? "Véhicule 5" : null));
        drivers.add(new Driver(4, "Fatima Benali", "+212 6 55 66 77 88", rand.nextBoolean() ? "Véhicule 2" : null));
        drivers.add(new Driver(5, "Omar Tazi", "+212 6 99 88 77 66", rand.nextBoolean() ? "Véhicule 7" : null));
        drivers.add(new Driver(6, "Laila Kadiri", "+212 6 44 33 22 11", null));
        drivers.add(new Driver(7, "Youssef Rahali", "+212 6 77 88 99 00", rand.nextBoolean() ? "Véhicule 4" : null));
        drivers.add(new Driver(8, "Aicha Bennis", "+212 6 33 44 55 66", null));
        drivers.add(new Driver(9, "Hassan Filali", "+212 6 22 11 00 99", rand.nextBoolean() ? "Véhicule 6" : null));
        drivers.add(new Driver(10, "Nadia Berrada", "+212 6 66 55 44 33", rand.nextBoolean() ? "Véhicule 8" : null));
    }

    private void deleteSelectedDriver() {
        int selectedRow = driversTable.getSelectedRow();
        
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, 
                "Veuillez sélectionner un conducteur à supprimer.", 
                "Aucune sélection", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        int driverId = (int) tableModel.getValueAt(selectedRow, 0);
        String driverName = (String) tableModel.getValueAt(selectedRow, 1);
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Êtes-vous sûr de vouloir supprimer le conducteur :\n" +
            "ID: " + driverId + "\n" +
            "Nom: " + driverName + "\n\n" +
            "Cette action est irréversible.",
            "Confirmer la suppression",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            drivers.removeIf(driver -> driver.getId_driver() == driverId);
            updateDriversTable();
            
            JOptionPane.showMessageDialog(this,
                "Le conducteur " + driverName + " a été supprimé avec succès.",
                "Suppression réussie",
                JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private JPanel createDriversPanel() {
        JPanel driversPanel = new JPanel(new BorderLayout());
        driversPanel.setBackground(Color.DARK_GRAY);
        driversPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel title = new JLabel("👥 GESTION DES CONDUCTEURS", SwingConstants.CENTER);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        driversPanel.add(title, BorderLayout.NORTH);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.DARK_GRAY);

        JPanel driverSearchPanel = new JPanel(new BorderLayout(10, 0));
        driverSearchPanel.setBackground(new Color(50, 50, 50));
        driverSearchPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.GRAY, 1),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        JLabel driverSearchIcon = new JLabel("🔍");
        driverSearchIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 18));
        driverSearchIcon.setForeground(Color.LIGHT_GRAY);
        driverSearchPanel.add(driverSearchIcon, BorderLayout.WEST);

        driverSearchField = new JTextField();
        driverSearchField.setForeground(Color.WHITE);
        driverSearchField.setBackground(new Color(60, 63, 65));
        driverSearchField.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        driverSearchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        addPlaceholder(driverSearchField, "Rechercher par ID, nom ou téléphone...");
        driverSearchPanel.add(driverSearchField, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonPanel.setBackground(new Color(50, 50, 50));

        JButton deleteDriverBtn = new JButton("Supprimer");
        deleteDriverBtn.setBackground(new Color(180, 70, 70));
        deleteDriverBtn.setForeground(Color.WHITE);
        deleteDriverBtn.setFont(new Font("Arial", Font.BOLD, 12));
        deleteDriverBtn.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        deleteDriverBtn.setFocusPainted(false);
        deleteDriverBtn.addActionListener(e -> deleteSelectedDriver());
        buttonPanel.add(deleteDriverBtn);

        JButton addDriverBtn = new JButton("Ajouter");
        addDriverBtn.setBackground(new Color(70, 130, 180));
        addDriverBtn.setForeground(Color.WHITE);
        addDriverBtn.setFont(new Font("Arial", Font.BOLD, 12));
        addDriverBtn.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        addDriverBtn.setFocusPainted(false);
        addDriverBtn.addActionListener(e -> showAddDriverDialog());
        buttonPanel.add(addDriverBtn);

        driverSearchPanel.add(buttonPanel, BorderLayout.EAST);

        mainPanel.add(driverSearchPanel, BorderLayout.NORTH);

        String[] columnNames = {"ID", "Nom", "Téléphone", "Véhicule Assigné", "Statut"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        driversTable = new JTable(tableModel);
        driversTable.setBackground(new Color(40, 40, 40));
        driversTable.setForeground(Color.WHITE);
        driversTable.setSelectionBackground(new Color(70, 130, 180));
        driversTable.setSelectionForeground(Color.WHITE);
        driversTable.setFont(new Font("Arial", Font.PLAIN, 12));
        driversTable.setRowHeight(35);

        JTableHeader header = driversTable.getTableHeader();
        header.setBackground(new Color(60, 60, 60));
        header.setForeground(Color.WHITE);
        header.setFont(new Font("Arial", Font.BOLD, 13));

        updateDriversTable();

        JScrollPane scrollPane = new JScrollPane(driversTable);
        scrollPane.setBackground(Color.DARK_GRAY);
        scrollPane.getViewport().setBackground(new Color(40, 40, 40));
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(20, 0, 0, 0),
            BorderFactory.createLineBorder(Color.GRAY, 1)
        ));

        mainPanel.add(scrollPane, BorderLayout.CENTER);
        driversPanel.add(mainPanel, BorderLayout.CENTER);

        driverSearchField.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) { filterDrivers(); }
            public void removeUpdate(DocumentEvent e) { filterDrivers(); }
            public void insertUpdate(DocumentEvent e) { filterDrivers(); }
        });

        return driversPanel;
    }

    private void updateDriversTable() {
        tableModel.setRowCount(0);
        for (Driver driver : drivers) {
            Object[] row = {
                driver.getId_driver(),
                driver.getName(),
                driver.getPhoneNumber(),
                driver.getVehicle() != null ? driver.getVehicle() : "Non assigné",
                driver.getVehicle() != null ? "🟢 En service" : "🟡 Disponible"
            };
            tableModel.addRow(row);
        }
    }

    private void filterDrivers() {
        String searchText = driverSearchField.getText().toLowerCase().trim();
        tableModel.setRowCount(0);
        
        for (Driver driver : drivers) {
            if (String.valueOf(driver.getId_driver()).contains(searchText) ||
                driver.getName().toLowerCase().contains(searchText) || 
                driver.getPhoneNumber().contains(searchText)) {
                Object[] row = {
                    driver.getId_driver(),
                    driver.getName(),
                    driver.getPhoneNumber(),
                    driver.getVehicle() != null ? driver.getVehicle() : "Non assigné",
                    driver.getVehicle() != null ? "🟢 En service" : "🟡 Disponible"
                };
                tableModel.addRow(row);
            }
        }
    }

    private void showAddDriverDialog() {
        JDialog dialog = new JDialog(this, "Ajouter un nouveau conducteur", true);
        dialog.setSize(400, 300);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.DARK_GRAY);
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JTextField nameField = new JTextField(15);
        JTextField phoneField = new JTextField(15);

        gbc.gridx = 0; gbc.gridy = 0;
        JLabel nameLabel = new JLabel("Nom:");
        nameLabel.setForeground(Color.WHITE);
        formPanel.add(nameLabel, gbc);

        gbc.gridx = 1;
        formPanel.add(nameField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        JLabel phoneLabel = new JLabel("Téléphone:");
        phoneLabel.setForeground(Color.WHITE);
        formPanel.add(phoneLabel, gbc);

        gbc.gridx = 1;
        formPanel.add(phoneField, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(Color.DARK_GRAY);

        JButton saveBtn = new JButton("Enregistrer");
        saveBtn.setBackground(new Color(70, 130, 180));
        saveBtn.setForeground(Color.WHITE);
        saveBtn.addActionListener(e -> {
            if (!nameField.getText().trim().isEmpty() && !phoneField.getText().trim().isEmpty()) {
                int newId = drivers.size() + 1;
                drivers.add(new Driver(newId, nameField.getText().trim(), phoneField.getText().trim(), null));
                updateDriversTable();
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog, "Veuillez remplir tous les champs.");
            }
        });

        JButton cancelBtn = new JButton("Annuler");
        cancelBtn.addActionListener(e -> dialog.dispose());

        buttonPanel.add(saveBtn);
        buttonPanel.add(cancelBtn);

        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void createVehiclePanels() {
        for (int i = 0; i < 10; i++) {
            String vehName = "Véhicule " + (i + 1);
            vehicleNames.add(vehName);

            JPanel vehiclePanel = new JPanel(new BorderLayout());
            vehiclePanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
            vehiclePanel.setBackground(Color.DARK_GRAY);

            JPanel mainPanel = new JPanel(new GridLayout(2, 3, 15, 15));
            mainPanel.setBackground(Color.DARK_GRAY);

            gauges[i][0] = new Gauge("Vitesse", "km/h", 0, 220);
            gauges[i][1] = new Gauge("Régime", "RPM", 0, 8000);
            gauges[i][2] = new Gauge("Tension", "V", 0, 15);
            levelIndicators[i][0] = new LevelIndicator("Niveau de carburant");
            levelIndicators[i][1] = new LevelIndicator("Niveau d'huile");
            levelIndicators[i][2] = new LevelIndicator("Niveau d'huile de frein");

            for (int j = 0; j < 3; j++) {
                mainPanel.add(gauges[i][j]);
            }
            for (int j = 0; j < 3; j++) {
                mainPanel.add(levelIndicators[i][j]);
            }

            JPanel rightPanel = new JPanel();
            rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
            rightPanel.setBackground(Color.DARK_GRAY);
            rightPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));

            JPanel thermoPanel = new JPanel(new GridLayout(1, 2, 15, 15));
            thermoPanel.setBackground(Color.DARK_GRAY);
            
            thermometers[i] = new Thermometer("Température");
            thermoPanel.add(thermometers[i]);
            
            extThermometers[i] = new Thermometer("Extérieure");
            thermoPanel.add(extThermometers[i]);
            
            rightPanel.add(thermoPanel);
            rightPanel.add(Box.createVerticalStrut(25));

            createTireSection(rightPanel, i);
            rightPanel.add(Box.createVerticalStrut(25));
            createDiagnosticsSection(rightPanel, i);

            vehiclePanel.add(mainPanel, BorderLayout.CENTER);
            vehiclePanel.add(rightPanel, BorderLayout.EAST);

            vehiclePanels.add(vehiclePanel);
            tabbedPane.addTab(vehName, vehiclePanel);
        }
    }

    private void createTireSection(JPanel rightPanel, int i) {
        JPanel tireMainPanel = new JPanel(new BorderLayout());
        tireMainPanel.setBackground(new Color(50, 50, 50));
        tireMainPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(100, 100, 100), 2),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        JLabel tireTitle = new JLabel("🚗 PRESSION DES PNEUS", SwingConstants.CENTER);
        tireTitle.setForeground(Color.WHITE);
        tireTitle.setFont(new Font("Arial", Font.BOLD, 16));
        tireMainPanel.add(tireTitle, BorderLayout.NORTH);
        
        JPanel tireGrid = new JPanel(new GridLayout(2, 2, 10, 10));
        tireGrid.setBackground(new Color(50, 50, 50));
        tireGrid.setBorder(BorderFactory.createEmptyBorder(15, 0, 0, 0));
        
        String[] tirePositions = {"Avant Gauche", "Avant Droite", "Arrière Gauche", "Arrière Droite"};
        
        for (int j = 0; j < 4; j++) {
            tirePanels[i][j] = new JPanel(new BorderLayout());
            tirePanels[i][j].setBackground(new Color(40, 40, 40));
            tirePanels[i][j].setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.GRAY, 1),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
            ));
            
            JLabel positionLabel = new JLabel(tirePositions[j], SwingConstants.CENTER);
            positionLabel.setForeground(Color.LIGHT_GRAY);
            positionLabel.setFont(new Font("Arial", Font.PLAIN, 11));
            
            tirePressureLabels[i][j] = new JLabel("2.4 bar", SwingConstants.CENTER);
            tirePressureLabels[i][j].setForeground(Color.WHITE);
            tirePressureLabels[i][j].setFont(new Font("Arial", Font.BOLD, 20));
            
            tirePanels[i][j].add(positionLabel, BorderLayout.NORTH);
            tirePanels[i][j].add(tirePressureLabels[i][j], BorderLayout.CENTER);
            tireGrid.add(tirePanels[i][j]);
        }
        
        tireMainPanel.add(tireGrid, BorderLayout.CENTER);
        rightPanel.add(tireMainPanel);
    }

    private void createDiagnosticsSection(JPanel rightPanel, int i) {
        JPanel diagnosticsPanel = new JPanel();
        diagnosticsPanel.setLayout(new BoxLayout(diagnosticsPanel, BoxLayout.Y_AXIS));
        diagnosticsPanel.setBackground(Color.DARK_GRAY);
        
        dtcPanels[i] = new JPanel(new BorderLayout());
        dtcPanels[i].setBackground(new Color(60, 40, 40));
        dtcPanels[i].setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.RED, 2),
            BorderFactory.createEmptyBorder(12, 15, 12, 15)
        ));
        
        JLabel dtcIcon = new JLabel("⚠️", SwingConstants.LEFT);
        dtcIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
        
        JPanel dtcContent = new JPanel(new BorderLayout());
        dtcContent.setBackground(new Color(60, 40, 40));
        
        JLabel dtcTitle = new JLabel("CODE DIAGNOSTIC");
        dtcTitle.setForeground(Color.WHITE);
        dtcTitle.setFont(new Font("Arial", Font.BOLD, 12));
        
        dtcLabels[i] = new JLabel("P0000");
        dtcLabels[i].setForeground(Color.WHITE);
        dtcLabels[i].setFont(new Font("Arial", Font.BOLD, 18));
        
        dtcContent.add(dtcTitle, BorderLayout.NORTH);
        dtcContent.add(dtcLabels[i], BorderLayout.CENTER);
        
        dtcPanels[i].add(dtcIcon, BorderLayout.WEST);
        dtcPanels[i].add(dtcContent, BorderLayout.CENTER);
        
        diagnosticsPanel.add(dtcPanels[i]);
        diagnosticsPanel.add(Box.createVerticalStrut(15));
        
        smokePanels[i] = new JPanel(new BorderLayout());
        smokePanels[i].setBackground(new Color(40, 60, 40));
        smokePanels[i].setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.GREEN, 2),
            BorderFactory.createEmptyBorder(12, 15, 12, 15)
        ));
        
        JLabel smokeIcon = new JLabel("💨", SwingConstants.LEFT);
        smokeIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
        
        JPanel smokeContent = new JPanel(new BorderLayout());
        smokeContent.setBackground(new Color(40, 60, 40));
        
        JLabel smokeTitle = new JLabel("DÉTECTION FUMÉE");
        smokeTitle.setForeground(Color.WHITE);
        smokeTitle.setFont(new Font("Arial", Font.BOLD, 12));
        
        smokeLabels[i] = new JLabel("Non détectée");
        smokeLabels[i].setForeground(Color.WHITE);
        smokeLabels[i].setFont(new Font("Arial", Font.BOLD, 16));
        
        smokeContent.add(smokeTitle, BorderLayout.NORTH);
        smokeContent.add(smokeLabels[i], BorderLayout.CENTER);
        
        smokePanels[i].add(smokeIcon, BorderLayout.WEST);
        smokePanels[i].add(smokeContent, BorderLayout.CENTER);
        
        diagnosticsPanel.add(smokePanels[i]);
        diagnosticsPanel.add(Box.createVerticalStrut(15));
        
        vibrationPanels[i] = new JPanel(new BorderLayout());
        vibrationPanels[i].setBackground(new Color(50, 50, 60));
        vibrationPanels[i].setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.CYAN, 2),
            BorderFactory.createEmptyBorder(12, 15, 12, 15)
        ));
        
        JLabel vibrationIcon = new JLabel("📳", SwingConstants.LEFT);
        vibrationIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
        
        JPanel vibrationContent = new JPanel(new BorderLayout());
        vibrationContent.setBackground(new Color(50, 50, 60));
        
        JLabel vibrationTitle = new JLabel("NIVEAU VIBRATION");
        vibrationTitle.setForeground(Color.WHITE);
        vibrationTitle.setFont(new Font("Arial", Font.BOLD, 12));
        
        vibrationLabels[i] = new JLabel("0.12 g");
        vibrationLabels[i].setForeground(Color.WHITE);
        vibrationLabels[i].setFont(new Font("Arial", Font.BOLD, 16));
        
        vibrationContent.add(vibrationTitle, BorderLayout.NORTH);
        vibrationContent.add(vibrationLabels[i], BorderLayout.CENTER);
        
        vibrationPanels[i].add(vibrationIcon, BorderLayout.WEST);
        vibrationPanels[i].add(vibrationContent, BorderLayout.CENTER);
        
        diagnosticsPanel.add(vibrationPanels[i]);

        rightPanel.add(diagnosticsPanel);
    }

    private void addPlaceholder(JTextField textField, String placeholder) {
        textField.setUI(new javax.swing.plaf.basic.BasicTextFieldUI() {
            @Override
            protected void paintSafely(Graphics g) {
                super.paintSafely(g);
                if (textField.getText().isEmpty() && !textField.hasFocus()) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(Color.GRAY);
                    Insets ins = textField.getInsets();
                    FontMetrics fm = g2.getFontMetrics();
                    int x = ins.left;
                    int y = textField.getHeight() / 2 + fm.getAscent() / 2 - 2;
                    g2.drawString(placeholder, x, y);
                    g2.dispose();
                }
            }
        });
    }

    private void filterTabs() {
        String text = searchField.getText().trim().toLowerCase();
        
        Component driversTab = null;
        String driversTabTitle = null;
        if (tabbedPane.getTabCount() > 0 && tabbedPane.getTitleAt(0).contains("Conducteurs")) {
            driversTab = tabbedPane.getComponentAt(0);
            driversTabTitle = tabbedPane.getTitleAt(0);
        }
        
        tabbedPane.removeAll();
        
        if (driversTab != null) {
            tabbedPane.addTab(driversTabTitle, driversTab);
        }

        for (int i = 0; i < vehicleNames.size(); i++) {
            if (vehicleNames.get(i).toLowerCase().contains(text)) {
                tabbedPane.addTab(vehicleNames.get(i), vehiclePanels.get(i));
            }
        }
    }

    private void updateValues() {
        Random rand = new Random();
        
        for (int i = 0; i < 10; i++) {
            String vehicleName = "Véhicule " + (i + 1);
            
            // Mettre à jour les gauges
            gauges[i][0].setValue((float) (rand.nextInt(180)));
            gauges[i][1].setValue((float) (1000 + rand.nextInt(6000)));
            gauges[i][2].setValue((float) (12 + rand.nextFloat() * 2));
            
            // Mettre à jour les level indicators
            levelIndicators[i][0].setOilLevel((float) (30 + rand.nextInt(70))); // Carburant
            levelIndicators[i][1].setOilLevel((float) (30 + rand.nextInt(70))); // Huile
            levelIndicators[i][2].setOilLevel((float) (30 + rand.nextInt(70))); // Huile de frein
            
            // Températures
            thermometers[i].setTemperature((float) (70 + rand.nextInt(30)));
            extThermometers[i].setTemperature((float) (-10 + rand.nextInt(40)));
            
            // Pression des pneus
            for (int j = 0; j < 4; j++) {
                float pressure = 2.0f + rand.nextFloat() * 0.8f;
                tirePressureLabels[i][j].setText(String.format("%.1f bar", pressure));
                
                if (pressure < 2.2f) {
                    tirePanels[i][j].setBackground(new Color(80, 30, 30));
                    tirePanels[i][j].setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Color.RED, 2),
                        BorderFactory.createEmptyBorder(10, 10, 10, 10)
                    ));
                    tirePressureLabels[i][j].setForeground(Color.RED);
                    
                    // Générer une alerte pour pression basse
                    String alertMessage = vehicleName + " - Pression pneu basse (" + (pressure < 2.0f ? "CRITIQUE" : "HAUTE") + ")";
                    if (!alertSeverity.containsKey(alertMessage)) {
                        alertsListModel.addElement(alertMessage);
                        alertSeverity.put(alertMessage, pressure < 2.0f ? "CRITIQUE" : "HAUTE");
                    }
                } else if (pressure > 2.6f) {
                    tirePanels[i][j].setBackground(new Color(80, 60, 30));
                    tirePanels[i][j].setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Color.ORANGE, 2),
                        BorderFactory.createEmptyBorder(10, 10, 10, 10)
                    ));
                    tirePressureLabels[i][j].setForeground(Color.ORANGE);
                    
                    // Générer une alerte pour pression haute
                    String alertMessage = vehicleName + " - Pression pneu haute (MOYENNE)";
                    if (!alertSeverity.containsKey(alertMessage)) {
                        alertsListModel.addElement(alertMessage);
                        alertSeverity.put(alertMessage, "MOYENNE");
                    }
                } else {
                    tirePanels[i][j].setBackground(new Color(30, 80, 30));
                    tirePanels[i][j].setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Color.GREEN, 2),
                        BorderFactory.createEmptyBorder(10, 10, 10, 10)
                    ));
                    tirePressureLabels[i][j].setForeground(Color.GREEN);
                }
            }
            
            // Code DTC
            if (rand.nextFloat() < 0.2f) {
                String dtcCode = DTC_CODES[rand.nextInt(DTC_CODES.length)];
                dtcLabels[i].setText(dtcCode);
                dtcPanels[i].setBackground(new Color(80, 30, 30));
                dtcPanels[i].setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(Color.RED, 3),
                    BorderFactory.createEmptyBorder(12, 15, 12, 15)
                ));
                
                String severity = (dtcCode.equals("P0300") || dtcCode.equals("P0171")) ? "CRITIQUE" : "HAUTE";
                if (dtcCode.equals("P0000")) severity = "BASSE";
                
                dtcLabels[i].setForeground(severity.equals("CRITIQUE") ? Color.YELLOW : Color.RED);
                
                // Générer une alerte pour code DTC
                String alertMessage = vehicleName + " - Code erreur: " + dtcCode + " (" + severity + ")";
                if (!alertSeverity.containsKey(alertMessage)) {
                    alertsListModel.addElement(alertMessage);
                    alertSeverity.put(alertMessage, severity);
                }
            } else {
                dtcLabels[i].setText("P0000 - AUCUN");
                dtcPanels[i].setBackground(new Color(30, 80, 30));
                dtcPanels[i].setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(Color.GREEN, 2),
                    BorderFactory.createEmptyBorder(12, 15, 12, 15)
                ));
                dtcLabels[i].setForeground(Color.GREEN);
            }
            
            // Fumée
            if (rand.nextFloat() < 0.1f) {
                smokeLabels[i].setText("⚠️ DÉTECTÉE");
                smokePanels[i].setBackground(new Color(80, 30, 30));
                smokePanels[i].setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(Color.RED, 3),
                    BorderFactory.createEmptyBorder(12, 15, 12, 15)
                ));
                smokeLabels[i].setForeground(Color.RED);
                
                // Générer une alerte pour fumée
                String alertMessage = vehicleName + " - Fumée détectée (CRITIQUE)";
                if (!alertSeverity.containsKey(alertMessage)) {
                    alertsListModel.addElement(alertMessage);
                    alertSeverity.put(alertMessage, "CRITIQUE");
                }
            } else {
                smokeLabels[i].setText("✅ NORMALE");
                smokePanels[i].setBackground(new Color(30, 80, 30));
                smokePanels[i].setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(Color.GREEN, 2),
                    BorderFactory.createEmptyBorder(12, 15, 12, 15)
                ));
                smokeLabels[i].setForeground(Color.GREEN);
            }
            
            // Vibration
            float vibration = 0.05f + rand.nextFloat() * 0.3f;
            vibrationLabels[i].setText(String.format("%.2f g", vibration));
            
            if (vibration > 0.25f) {
                vibrationPanels[i].setBackground(new Color(80, 60, 30));
                vibrationPanels[i].setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(Color.ORANGE, 2),
                    BorderFactory.createEmptyBorder(12, 15, 12, 15)
                ));
                vibrationLabels[i].setForeground(Color.ORANGE);
                
                // Générer une alerte pour vibration
                String alertMessage = vehicleName + " - Vibration excessive (HAUTE)";
                if (!alertSeverity.containsKey(alertMessage)) {
                    alertsListModel.addElement(alertMessage);
                    alertSeverity.put(alertMessage, "HAUTE");
                }
            } else if (vibration > 0.15f) {
                vibrationPanels[i].setBackground(new Color(80, 80, 30));
                vibrationPanels[i].setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(Color.YELLOW, 2),
                    BorderFactory.createEmptyBorder(12, 15, 12, 15)
                ));
                vibrationLabels[i].setForeground(Color.YELLOW);
                
                // Générer une alerte pour vibration
                String alertMessage = vehicleName + " - Vibration anormale (MOYENNE)";
                if (!alertSeverity.containsKey(alertMessage)) {
                    alertsListModel.addElement(alertMessage);
                    alertSeverity.put(alertMessage, "MOYENNE");
                }
            } else {
                vibrationPanels[i].setBackground(new Color(30, 80, 30));
                vibrationPanels[i].setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(Color.GREEN, 2),
                    BorderFactory.createEmptyBorder(12, 15, 12, 15)
                ));
                vibrationLabels[i].setForeground(Color.GREEN);
            }
        }
        
        repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new Dashboard().setVisible(true);
        });
    }
}